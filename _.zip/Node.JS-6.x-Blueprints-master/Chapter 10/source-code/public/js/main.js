$(function() {
  // Custom JavaScript code
});
